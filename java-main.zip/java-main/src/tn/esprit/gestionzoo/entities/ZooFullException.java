package tn.esprit.gestionzoo.entities;

public class ZooFullException extends Exception {
    public ZooFullException(String message) {
        super(message);
    }
}