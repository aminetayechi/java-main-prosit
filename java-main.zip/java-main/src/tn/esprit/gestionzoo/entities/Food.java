package tn.esprit.gestionzoo.entities;

public enum Food { MEAT, PLANT, BOTH }
