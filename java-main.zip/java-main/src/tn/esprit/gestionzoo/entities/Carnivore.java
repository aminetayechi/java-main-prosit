package tn.esprit.gestionzoo.entities;

public interface Carnivore<T> {
    void eatMeat(T meat);
}
