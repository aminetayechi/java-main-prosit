package tn.esprit.gestionzoo.entities;

public interface Herbivore <T>  {
    void eatPlant(T plant);
}
